"use client"

import { useState } from "react"
import { Phone, Video, Mic, MicOff, VideoOff, PhoneOff } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"

export default function CallInterface() {
  const [isInCall, setIsInCall] = useState(false)
  const [isMuted, setIsMuted] = useState(false)
  const [isVideoOff, setIsVideoOff] = useState(false)

  if (isInCall) {
    return (
      <div className="flex flex-col h-[calc(100vh-140px)] pb-20 bg-gray-900 text-white rounded-lg overflow-hidden">
        {/* Video Area */}
        <div className="flex-1 relative bg-gradient-to-br from-gray-800 to-gray-900">
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-center">
              <Avatar className="w-32 h-32 mx-auto mb-4">
                <AvatarFallback className="bg-primary text-primary-foreground text-4xl">S</AvatarFallback>
              </Avatar>
              <h3 className="text-2xl font-semibold">Sarah Johnson</h3>
              <p className="text-gray-300">Connected</p>
            </div>
          </div>

          {/* Self Video Preview */}
          <div className="absolute top-4 right-4 w-32 h-24 bg-gray-700 rounded-lg border-2 border-gray-600">
            <div className="w-full h-full flex items-center justify-center">
              <Avatar className="w-12 h-12">
                <AvatarFallback className="bg-secondary text-secondary-foreground">Y</AvatarFallback>
              </Avatar>
            </div>
          </div>
        </div>

        {/* Call Controls */}
        <div className="p-6 bg-gray-800">
          <div className="flex items-center justify-center gap-4">
            <Button
              variant={isMuted ? "destructive" : "secondary"}
              size="lg"
              className="rounded-full w-14 h-14"
              onClick={() => setIsMuted(!isMuted)}
            >
              {isMuted ? <MicOff className="w-6 h-6" /> : <Mic className="w-6 h-6" />}
            </Button>

            <Button
              variant="destructive"
              size="lg"
              className="rounded-full w-16 h-16"
              onClick={() => setIsInCall(false)}
            >
              <PhoneOff className="w-8 h-8" />
            </Button>

            <Button
              variant={isVideoOff ? "destructive" : "secondary"}
              size="lg"
              className="rounded-full w-14 h-14"
              onClick={() => setIsVideoOff(!isVideoOff)}
            >
              {isVideoOff ? <VideoOff className="w-6 h-6" /> : <Video className="w-6 h-6" />}
            </Button>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6 pb-20">
      <div className="text-center py-8">
        <h2 className="text-2xl font-bold text-foreground mb-2">Voice & Video Calls</h2>
        <p className="text-muted-foreground">Connect with your study partners</p>
      </div>

      {/* Recent Contacts */}
      <div className="space-y-4">
        <h3 className="text-lg font-semibold text-foreground">Recent Contacts</h3>

        <Card className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Avatar>
                <AvatarFallback className="bg-primary text-primary-foreground">S</AvatarFallback>
              </Avatar>
              <div>
                <h4 className="font-medium text-foreground">Sarah Johnson</h4>
                <p className="text-sm text-muted-foreground">Last called 2 hours ago</p>
              </div>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" size="icon" onClick={() => setIsInCall(true)}>
                <Phone className="w-4 h-4" />
              </Button>
              <Button variant="outline" size="icon" onClick={() => setIsInCall(true)}>
                <Video className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </Card>

        <Card className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Avatar>
                <AvatarFallback className="bg-secondary text-secondary-foreground">M</AvatarFallback>
              </Avatar>
              <div>
                <h4 className="font-medium text-foreground">Mike Chen</h4>
                <p className="text-sm text-muted-foreground">Last called yesterday</p>
              </div>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" size="icon">
                <Phone className="w-4 h-4" />
              </Button>
              <Button variant="outline" size="icon">
                <Video className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </Card>
      </div>
    </div>
  )
}
