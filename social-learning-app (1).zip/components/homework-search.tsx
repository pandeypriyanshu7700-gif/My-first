"use client"

import { useState } from "react"
import { Search, BookOpen, Calculator, Beaker, Globe } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

interface SearchResult {
  id: string
  title: string
  subject: string
  description: string
  difficulty: "Easy" | "Medium" | "Hard"
  icon: any
}

export default function HomeworkSearch() {
  const [searchQuery, setSearchQuery] = useState("")
  const [results, setResults] = useState<SearchResult[]>([
    {
      id: "1",
      title: "Quadratic Equations Solver",
      subject: "Mathematics",
      description: "Step-by-step solutions for quadratic equations with detailed explanations",
      difficulty: "Medium",
      icon: Calculator,
    },
    {
      id: "2",
      title: "Photosynthesis Process",
      subject: "Biology",
      description: "Complete guide to understanding photosynthesis in plants",
      difficulty: "Easy",
      icon: Beaker,
    },
    {
      id: "3",
      title: "World War II Timeline",
      subject: "History",
      description: "Comprehensive timeline of major events during WWII",
      difficulty: "Medium",
      icon: Globe,
    },
  ])

  const handleSearch = () => {
    // In a real app, this would make an API call
    console.log("Searching for:", searchQuery)
  }

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "Easy":
        return "bg-green-100 text-green-800"
      case "Medium":
        return "bg-yellow-100 text-yellow-800"
      case "Hard":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  return (
    <div className="space-y-6 pb-20">
      <div className="text-center py-8">
        <h2 className="text-2xl font-bold text-foreground mb-2">Homework Helper</h2>
        <p className="text-muted-foreground">Find solutions and explanations for your assignments</p>
      </div>

      {/* Search Bar */}
      <div className="flex gap-2">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search for homework help..."
            className="pl-10"
            onKeyPress={(e) => e.key === "Enter" && handleSearch()}
          />
        </div>
        <Button onClick={handleSearch} className="bg-primary hover:bg-primary/90">
          Search
        </Button>
      </div>

      {/* Subject Categories */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <Button variant="outline" className="h-auto p-4 flex flex-col gap-2 bg-transparent">
          <Calculator className="w-6 h-6 text-primary" />
          <span className="text-sm">Math</span>
        </Button>
        <Button variant="outline" className="h-auto p-4 flex flex-col gap-2 bg-transparent">
          <Beaker className="w-6 h-6 text-primary" />
          <span className="text-sm">Science</span>
        </Button>
        <Button variant="outline" className="h-auto p-4 flex flex-col gap-2 bg-transparent">
          <BookOpen className="w-6 h-6 text-primary" />
          <span className="text-sm">Literature</span>
        </Button>
        <Button variant="outline" className="h-auto p-4 flex flex-col gap-2 bg-transparent">
          <Globe className="w-6 h-6 text-primary" />
          <span className="text-sm">History</span>
        </Button>
      </div>

      {/* Search Results */}
      <div className="space-y-4">
        <h3 className="text-lg font-semibold text-foreground">Popular Resources</h3>

        {results.map((result) => (
          <Card key={result.id} className="p-4 hover:shadow-md transition-shadow">
            <div className="flex items-start gap-4">
              <div className="p-2 bg-primary/10 rounded-lg">
                <result.icon className="w-6 h-6 text-primary" />
              </div>
              <div className="flex-1">
                <div className="flex items-start justify-between mb-2">
                  <h4 className="font-semibold text-foreground">{result.title}</h4>
                  <Badge className={getDifficultyColor(result.difficulty)}>{result.difficulty}</Badge>
                </div>
                <p className="text-sm text-muted-foreground mb-2">{result.description}</p>
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-primary">{result.subject}</span>
                  <Button size="sm" variant="outline">
                    View Solution
                  </Button>
                </div>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  )
}
