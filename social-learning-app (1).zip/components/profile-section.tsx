"use client"

import { Settings, Bell, HelpCircle, LogOut } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Switch } from "@/components/ui/switch"

export default function ProfileSection() {
  return (
    <div className="space-y-6 pb-20">
      {/* Profile Header */}
      <Card className="p-6">
        <div className="flex items-center gap-4 mb-4">
          <Avatar className="w-20 h-20">
            <AvatarFallback className="bg-primary text-primary-foreground text-2xl">Y</AvatarFallback>
          </Avatar>
          <div>
            <h2 className="text-2xl font-bold text-foreground">Your Name</h2>
            <p className="text-muted-foreground">Student at University</p>
            <p className="text-sm text-muted-foreground">Joined March 2024</p>
          </div>
        </div>
        <Button variant="outline" className="w-full bg-transparent">
          Edit Profile
        </Button>
      </Card>

      {/* Settings */}
      <div className="space-y-4">
        <h3 className="text-lg font-semibold text-foreground">Settings</h3>

        <Card className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Bell className="w-5 h-5 text-muted-foreground" />
              <div>
                <h4 className="font-medium text-foreground">Notifications</h4>
                <p className="text-sm text-muted-foreground">Get notified about messages and calls</p>
              </div>
            </div>
            <Switch />
          </div>
        </Card>

        <Card className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Settings className="w-5 h-5 text-muted-foreground" />
              <div>
                <h4 className="font-medium text-foreground">App Settings</h4>
                <p className="text-sm text-muted-foreground">Customize your experience</p>
              </div>
            </div>
            <Button variant="ghost" size="sm">
              Configure
            </Button>
          </div>
        </Card>

        <Card className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <HelpCircle className="w-5 h-5 text-muted-foreground" />
              <div>
                <h4 className="font-medium text-foreground">Help & Support</h4>
                <p className="text-sm text-muted-foreground">Get help and contact support</p>
              </div>
            </div>
            <Button variant="ghost" size="sm">
              View
            </Button>
          </div>
        </Card>

        <Card className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <LogOut className="w-5 h-5 text-destructive" />
              <div>
                <h4 className="font-medium text-destructive">Sign Out</h4>
                <p className="text-sm text-muted-foreground">Sign out of your account</p>
              </div>
            </div>
            <Button variant="destructive" size="sm">
              Sign Out
            </Button>
          </div>
        </Card>
      </div>
    </div>
  )
}
