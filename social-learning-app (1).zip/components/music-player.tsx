"use client"

import { useState } from "react"
import { Play, Pause, SkipBack, SkipForward, Volume2, Shuffle, Repeat } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Slider } from "@/components/ui/slider"

interface Song {
  id: string
  title: string
  artist: string
  duration: string
  category: string
}

export default function MusicPlayer() {
  const [isPlaying, setIsPlaying] = useState(false)
  const [currentSong, setCurrentSong] = useState<Song>({
    id: "1",
    title: "Focus Flow",
    artist: "Study Beats",
    duration: "3:45",
    category: "Lo-fi",
  })
  const [volume, setVolume] = useState([75])
  const [progress, setProgress] = useState([30])

  const playlists = [
    { name: "Focus Music", count: 25, color: "bg-blue-500" },
    { name: "Lo-fi Beats", count: 18, color: "bg-purple-500" },
    { name: "Classical Study", count: 32, color: "bg-green-500" },
    { name: "Nature Sounds", count: 15, color: "bg-orange-500" },
  ]

  const songs: Song[] = [
    { id: "1", title: "Focus Flow", artist: "Study Beats", duration: "3:45", category: "Lo-fi" },
    { id: "2", title: "Peaceful Mind", artist: "Calm Collective", duration: "4:12", category: "Ambient" },
    { id: "3", title: "Study Session", artist: "Focus Music", duration: "3:28", category: "Lo-fi" },
    { id: "4", title: "Rain Drops", artist: "Nature Sounds", duration: "5:00", category: "Nature" },
  ]

  return (
    <div className="space-y-6 pb-20">
      <div className="text-center py-8">
        <h2 className="text-2xl font-bold text-foreground mb-2">Study Music</h2>
        <p className="text-muted-foreground">Focus better with curated playlists</p>
      </div>

      {/* Current Playing */}
      <Card className="p-6">
        <div className="text-center mb-6">
          <div className="w-32 h-32 bg-gradient-to-br from-primary to-secondary rounded-lg mx-auto mb-4 flex items-center justify-center">
            <div className="text-4xl">🎵</div>
          </div>
          <h3 className="text-xl font-semibold text-foreground">{currentSong.title}</h3>
          <p className="text-muted-foreground">{currentSong.artist}</p>
        </div>

        {/* Progress Bar */}
        <div className="space-y-2 mb-6">
          <Slider value={progress} onValueChange={setProgress} max={100} step={1} className="w-full" />
          <div className="flex justify-between text-sm text-muted-foreground">
            <span>1:15</span>
            <span>{currentSong.duration}</span>
          </div>
        </div>

        {/* Controls */}
        <div className="flex items-center justify-center gap-4 mb-6">
          <Button variant="ghost" size="icon">
            <Shuffle className="w-5 h-5" />
          </Button>
          <Button variant="ghost" size="icon">
            <SkipBack className="w-5 h-5" />
          </Button>
          <Button
            size="lg"
            className="rounded-full w-14 h-14 bg-primary hover:bg-primary/90"
            onClick={() => setIsPlaying(!isPlaying)}
          >
            {isPlaying ? <Pause className="w-6 h-6" /> : <Play className="w-6 h-6 ml-1" />}
          </Button>
          <Button variant="ghost" size="icon">
            <SkipForward className="w-5 h-5" />
          </Button>
          <Button variant="ghost" size="icon">
            <Repeat className="w-5 h-5" />
          </Button>
        </div>

        {/* Volume */}
        <div className="flex items-center gap-3">
          <Volume2 className="w-4 h-4 text-muted-foreground" />
          <Slider value={volume} onValueChange={setVolume} max={100} step={1} className="flex-1" />
        </div>
      </Card>

      {/* Playlists */}
      <div className="space-y-4">
        <h3 className="text-lg font-semibold text-foreground">Study Playlists</h3>
        <div className="grid grid-cols-2 gap-3">
          {playlists.map((playlist, index) => (
            <Card key={index} className="p-4 hover:shadow-md transition-shadow cursor-pointer">
              <div className="flex items-center gap-3">
                <div className={`w-12 h-12 ${playlist.color} rounded-lg flex items-center justify-center`}>
                  <div className="text-white text-xl">🎵</div>
                </div>
                <div>
                  <h4 className="font-medium text-foreground">{playlist.name}</h4>
                  <p className="text-sm text-muted-foreground">{playlist.count} songs</p>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>

      {/* Recent Songs */}
      <div className="space-y-4">
        <h3 className="text-lg font-semibold text-foreground">Recently Played</h3>
        {songs.map((song) => (
          <Card key={song.id} className="p-3 hover:shadow-md transition-shadow cursor-pointer">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Button variant="ghost" size="icon" className="w-8 h-8" onClick={() => setCurrentSong(song)}>
                  <Play className="w-4 h-4" />
                </Button>
                <div>
                  <h4 className="font-medium text-foreground">{song.title}</h4>
                  <p className="text-sm text-muted-foreground">{song.artist}</p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-sm text-muted-foreground">{song.duration}</p>
                <p className="text-xs text-muted-foreground">{song.category}</p>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  )
}
