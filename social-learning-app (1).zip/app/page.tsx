"use client"

import { useState } from "react"
import { MessageCircle, Video, Search, Music, Home, User } from "lucide-react"
import { Card } from "@/components/ui/card"
import ChatInterface from "@/components/chat-interface"
import CallInterface from "@/components/call-interface"
import HomeworkSearch from "@/components/homework-search"
import MusicPlayer from "@/components/music-player"
import ProfileSection from "@/components/profile-section"

type ActiveTab = "home" | "chat" | "call" | "search" | "music" | "profile"

export default function SocialLearningApp() {
  const [activeTab, setActiveTab] = useState<ActiveTab>("home")

  const renderContent = () => {
    switch (activeTab) {
      case "home":
        return <HomeContent />
      case "chat":
        return <ChatInterface />
      case "call":
        return <CallInterface />
      case "search":
        return <HomeworkSearch />
      case "music":
        return <MusicPlayer />
      case "profile":
        return <ProfileSection />
      default:
        return <HomeContent />
    }
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-card border-b border-border px-4 py-3">
        <div className="flex items-center justify-between max-w-6xl mx-auto">
          <h1 className="text-2xl font-bold text-primary">StudyConnect</h1>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
              <User className="w-4 h-4 text-primary-foreground" />
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 max-w-6xl mx-auto p-4">{renderContent()}</main>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 bg-card border-t border-border">
        <div className="flex items-center justify-around py-2 max-w-6xl mx-auto">
          <NavButton icon={Home} label="Home" active={activeTab === "home"} onClick={() => setActiveTab("home")} />
          <NavButton
            icon={MessageCircle}
            label="Chat"
            active={activeTab === "chat"}
            onClick={() => setActiveTab("chat")}
          />
          <NavButton icon={Video} label="Calls" active={activeTab === "call"} onClick={() => setActiveTab("call")} />
          <NavButton
            icon={Search}
            label="Homework"
            active={activeTab === "search"}
            onClick={() => setActiveTab("search")}
          />
          <NavButton icon={Music} label="Music" active={activeTab === "music"} onClick={() => setActiveTab("music")} />
        </div>
      </nav>
    </div>
  )
}

function NavButton({
  icon: Icon,
  label,
  active,
  onClick,
}: {
  icon: any
  label: string
  active: boolean
  onClick: () => void
}) {
  return (
    <button
      onClick={onClick}
      className={`flex flex-col items-center gap-1 p-2 rounded-lg transition-colors ${
        active ? "text-primary bg-primary/10" : "text-muted-foreground hover:text-foreground"
      }`}
    >
      <Icon className="w-5 h-5" />
      <span className="text-xs font-medium">{label}</span>
    </button>
  )
}

function HomeContent() {
  return (
    <div className="space-y-6 pb-20">
      <div className="text-center py-8">
        <h2 className="text-3xl font-bold text-foreground mb-2">Welcome to StudyConnect</h2>
        <p className="text-muted-foreground text-lg">Your all-in-one social learning platform</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <FeatureCard
          title="Chat with Friends"
          description="Connect with classmates and study together"
          icon={MessageCircle}
          color="bg-blue-500"
        />
        <FeatureCard
          title="Voice & Video Calls"
          description="Have face-to-face study sessions"
          icon={Video}
          color="bg-green-500"
        />
        <FeatureCard
          title="Homework Help"
          description="Search for solutions and explanations"
          icon={Search}
          color="bg-purple-500"
        />
        <FeatureCard
          title="Study Music"
          description="Focus with curated playlists"
          icon={Music}
          color="bg-orange-500"
        />
      </div>
    </div>
  )
}

function FeatureCard({
  title,
  description,
  icon: Icon,
  color,
}: {
  title: string
  description: string
  icon: any
  color: string
}) {
  return (
    <Card className="p-6 hover:shadow-lg transition-shadow">
      <div className="flex items-start gap-4">
        <div className={`p-3 rounded-lg ${color}`}>
          <Icon className="w-6 h-6 text-white" />
        </div>
        <div>
          <h3 className="font-semibold text-foreground mb-1">{title}</h3>
          <p className="text-muted-foreground text-sm">{description}</p>
        </div>
      </div>
    </Card>
  )
}
